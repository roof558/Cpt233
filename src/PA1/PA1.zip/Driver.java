package MicroAssignment2;

public class Driver {
	public static void main(String[] args) {
		Banchmarking a1 = new Banchmarking("input2.txt");
		System.out.println(a1.printList());
		System.out.println(a1.toString());
	}
	
}
